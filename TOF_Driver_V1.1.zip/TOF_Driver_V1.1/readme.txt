How to use this driver

1. Define PA4-Pin as Input (No pull-up and no pull-down) and call it "VL53LX_INT"
2. Define PB8 and PB9 as I2C1 interface
3. Copy driver (this folder) into the "Drivers" folder of the project
4. In main.c include "vl53lx.h"
5. Make sure printf is correctly redirected to UART (only important, if printf is used)
6. Define a measurement variable of type "VL53LX_MultiRangingData_t" and a Device Variable of type "VL53LX_Dev_t"
7. In "int main(void)" section use "VL53LX_Init()"-function to initialize time-of-flight sensor for program run time
8. In "int main(void)" section use "VL53LX_GetData()"-function to get measurement data from time-of-flight sensor
9. Measurement values are stored into MultiRangingData

Different values and multiple measurements (if there was more than one object found) are stored into the measurement variable.
Example for how to access a certain value in main.c (here distance):
 
int16_t distance = MultiRangingData.RangeData[i].RangeMilliMeter;

Like this different values can be accessed. 
Here you find the most important values that you can get from the time-of-flight sensor:


MultiRangingData.NumberOfObjectsFound
  	Indicate the number of objects found.
	uint8_t

MultiRangingData.StreamCount
	8-bit Stream Count.
	uint8_t

MultiRangingData.RangeData.AmbientRateRtnMegaCps
		Return ambient rate (MCPS)\n these is a 16.16 fix point 
		value, which is effectively a measure of the ambient
		light.
		FixPoint1616_t

MultiRangingData.RangeData.RangeMaxMilliMeter
		Tells what is the maximum detection distance of the object
		in current setup and environment conditions (Filled when
		applicable)
		int16_t

MultiRangingData.RangeData.RangeMinMilliMeter
		Tells what is the minimum detection distance of the object
		in current setup and environment conditions (Filled when
		applicable)
		int16_t

MultiRangingData.RangeData.RangeMilliMeter
		range distance in millimeter. This should be between
		RangeMinMilliMeter and RangeMaxMilliMeter
		int16_t

MultiRangingData.RangeData.RangeStatus
		Range Status for the current measurement. This is device
		dependent. Value = 0 means value is valid.
		uint8_t

MultiRangingData.RangeData.SigmaMilliMeter
		Return the Sigma value in millimeter
		FixPoint1616_t

MultiRangingData.RangeData.SignalRateRtnMegaCps
		Return signal rate (MCPS)\n these is a 16.16 fix point
		value, which is effectively a measure of target
		reflectance.
		FixPoint1616_t


Annotations:

	A working example is attached to this driver.






 

