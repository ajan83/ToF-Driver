/*
 * vl53lx.c
 *
 * Authors: Retus Rieben, Maurice Otto, Jan Villiger
 * Date: 04.11.2021
 * Version: V1.1
 * Function File of the vl53lx-Driver
 *
 * Changes: solved delayed measurement issue
 */
#include "vl53lx.h"
#include "vl53lx_api.h"

I2C_HandleTypeDef hi2c1;

static VL53LX_DEV Dev;
static int vl53lx_status;

/*
 * VL53LX_Init()
 * Setup-Function for the VL53LX Time-of-Flight Sensor
 */
void VL53LX_Init(VL53LX_Dev_t *dev,VL53LX_MultiRangingData_t *MultiRangingData)
{
	Dev=dev;
	uint8_t byteData;
	uint16_t wordData;
	uint8_t ToFSensor = 1; // 0=Left, 1=Center(default), 2=Right
	XNUCLEO53L3A2_Init();
	Dev->I2cHandle = &hi2c1;
	Dev->I2cDevAddr = 0x52;

	vl53lx_status = XNUCLEO53L3A2_ResetId(ToFSensor, 0); // Reset ToF sensor
	HAL_Delay(2);
	vl53lx_status = XNUCLEO53L3A2_ResetId(ToFSensor, 1); // Reset ToF sensor
	HAL_Delay(2);

	VL53LX_RdByte(Dev, 0x010F, &byteData);
	printf("\n\rVL53LX Model_ID: %02X\n\r", byteData);
	VL53LX_RdByte(Dev, 0x0110, &byteData);
	printf("VL53LX Module_Type: %02X\n\r", byteData);
	VL53LX_RdWord(Dev, 0x010F, &wordData);
	printf("VL53LX: %02X\n\r", wordData);

	vl53lx_status = VL53LX_WaitDeviceBooted(Dev);
	vl53lx_status = VL53LX_DataInit(Dev);
	vl53lx_status = VL53LX_StopMeasurement(Dev);

	if(vl53lx_status==0)
	{
		printf("VL53LX initialization successful\n\r");
	}
	else
	{
		printf("VL53LX initialization not successful\n\r");
	}

	vl53lx_status = VL53LX_StartMeasurement(Dev);
	HAL_Delay(30);

	VL53LX_GetData(Dev,MultiRangingData);
	VL53LX_GetData(Dev,MultiRangingData);//First measurements (no data)
	return;
}

/*
 * VL53LX_GetData()
 * Measurement-Function of the VL53LX Time-of-Flight Sensor
 * Data storage in MultiRangingData (needs to be defined in main.c)
 *
 * structure of MultiRangingData (VL53LX_MultiRangingData_t)

MultiRangingData.

  	NumberOfObjectsFound
  	!< Indicate the number of objects found.
	* This is used to know how many ranging data should be get.
	* NumberOfObjectsFound is in the range 0 to
	* VL53LX_MAX_RANGE_RESULTS.

	StreamCount
	!< 8-bit Stream Count.

	RangeData.
	!< Range data each target distance

		AmbientRateRtnMegaCps
		!< Return ambient rate (MCPS)\n these is a 16.16 fix point
		*  value, which is effectively a measure of the ambient
		*  light.

		RangeMaxMilliMeter
		!< Tells what is the maximum detection distance of the object
		*  in current setup and environment conditions (Filled when
		*  applicable)

		RangeMinMilliMeter
		!< Tells what is the minimum detection distance of the object
		*  in current setup and environment conditions (Filled when
		*  applicable)

		RangeMilliMeter
		!< range distance in millimeter. This should be between
		*  RangeMinMilliMeter and RangeMaxMilliMeter

		RangeStatus
		!< Range Status for the current measurement. This is device
		*  dependent. Value = 0 means value is valid.

		SigmaMilliMeter
		!< Return the Sigma value in millimeter

		SignalRateRtnMegaCps
		!< Return signal rate (MCPS)\n these is a 16.16 fix point
		*  value, which is effectively a measure of target
		*  reflectance.
 *
 */
void VL53LX_GetData(VL53LX_Dev_t *dev,VL53LX_MultiRangingData_t *MultiRangingData)
{
  vl53lx_status=VL53LX_ClearInterruptAndStartMeasurement(Dev);
  vl53lx_status=VL53LX_StartMeasurement(Dev);
  /************ Other Functions can be called here ************/
  HAL_Delay(40);
  /************ Min 40 ms must be spent here ************/
  if(vl53lx_status)
  {
    printf("VL53LX_StartMeasurement failed: error = %d \n", vl53lx_status);
    Error_Handler();
  }

  if(HAL_GPIO_ReadPin(GPIOA,VL53LX_INT_Pin)==0)
  {
	vl53lx_status = VL53LX_GetMultiRangingData(Dev, MultiRangingData);
	if(vl53lx_status!=0)
	{
		printf("VL53LX Measurement Error\r\n");
	}

  }

}
/*
 * VL53LX_PrintData()
 * Output data via UART Interface
 *
 */
void VL53LX_PrintData(VL53LX_MultiRangingData_t *MultiRangingData)
{
	int no_of_object_found;
	no_of_object_found=MultiRangingData->NumberOfObjectsFound;
	printf("Count=%5d, ", MultiRangingData->StreamCount);
	printf("#Objs=%1d ", no_of_object_found);
	for(int j=0;j<no_of_object_found;j++)
	{
		if(j!=0){printf("\n\r                     ");}
	  	printf("status=%d, D=%5dmm, Signal=%2.2f Mcps, Ambient=%2.2f Mcps",
	  		MultiRangingData->RangeData[j].RangeStatus,
	  		MultiRangingData->RangeData[j].RangeMilliMeter,
	  		MultiRangingData->RangeData[j].SignalRateRtnMegaCps/65536.0,
	  		MultiRangingData->RangeData[j].AmbientRateRtnMegaCps/65536.0);
	}
	printf("\n\r");
}
